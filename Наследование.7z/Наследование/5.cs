﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAppConsole
{
    class Pair
    {
        protected double p1;
        protected double p2;
        protected void SetField(double p1, double p2)
        {
            this.p1 = p1;
            this.p2 = p2;
        }
        protected double GetSub()
        {
            return p1 * p2;
        }
    }
    class Rectangle : Pair
    {
        double sideA;
        double sideB;
        public double GetPeremetr()
        {
            return 2 * (p1 + p2);
        }
        public double GetArea()
        {
            return GetSub();
        }
        public Rectangle(double sideA, double sideB)
        {
            SetField(sideA, sideB);
            this.sideA = sideA;
            this.sideB = sideB;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle tri = new Rectangle(10, 10);
            Console.WriteLine(tri.GetPeremetr());
            Console.WriteLine(tri.GetArea());
            Console.ReadKey();
        }
    }
}
