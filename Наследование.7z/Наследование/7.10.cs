using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] argc)
        {
            Console.WriteLine("������� ���������� �������� �����");
            int N = int.Parse(Console.ReadLine());
            int[] array = new int[N];
            for (int i = 0; i < N; i++)
            {
                array[i] = int.Parse(Console.ReadLine());
                if (array[i] == 0)
                    break;
            }
            for (int i = 0; i < array.Length; i++)
            {
                if (i % 2 == 0)
                    Console.WriteLine(array[i]);
            }
            Console.ReadKey();
        }
    }
}
