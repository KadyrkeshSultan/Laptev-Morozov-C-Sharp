﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAppConsole
{
    class Car
    {
        protected string marka;
        protected uint numCylynder;
        protected uint power;
        public virtual void Show()
        {
            Console.WriteLine("Name: {0}, Cylynder: {1}, Power: {2}", marka, numCylynder, power);
        }
        public void SetMarka(string name)
        {
            marka = name;
        }
        public void EditPower(uint Power)
        {
            power = Power;
        }
        public Car(string Name, uint Cylynder, uint Power)
        {
            marka = Name;
            numCylynder = Cylynder;
            power = Power;
        }
    }
    class Lorry : Car
    {
        uint gruzopod;
        public override void Show()
        {
            Console.WriteLine("Name: {0}, Cylynder: {1}, Power: {2}, Gruz: {3}", marka, numCylynder, power, gruzopod);   
        }
        public void EditGruzo(uint Gruzo)
        {
            gruzopod = Gruzo;
        }
        public Lorry(string name, uint Cylynder, uint Power, uint Gruz) :base(name, Cylynder, Power)
        {
            gruzopod = Gruz;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Lorry car = new Lorry("Kamaz", 10, 400, 500);
            car.Show();
            car.EditPower(500);
            car.SetMarka("Zil");
            car.EditGruzo(600);
            car.Show();
            Console.ReadKey();
        }
    }
}
