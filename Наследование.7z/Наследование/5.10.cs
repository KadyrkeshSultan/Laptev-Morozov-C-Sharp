using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{

    class Program
    {
        static int Equation(double a, double b, double c, out double x1, out double x2)
        {
            double D;
            D = (b * b) - (4 * a * c);
            if (a == 0.0 && b == 0.0 && c == 0.0 || a== 0.0 && b==0.0)
            {
                x1 = -1;
                x2 = x1;
                return -1;
            }
            if (D > 0)
            {
                x1 = (((-1) * b) + Math.Sqrt(D)) / (2 * a);
                x2 = (((-1) * b) - Math.Sqrt(D)) / (2 * a);
                return 2;
            }
            else if (D == 0)
            {
                x1 = ((-1) * b) / (2 * a);
                x2 = x1;
                return 1;
            }
            else
            {
                x1 = 0;
                x2 = x1;
                return 0;
            }
        }
        static void Main(string[] argc)
        {
            double a, b, c, x1,x2;
            Console.WriteLine(Equation(3, 4, 5, out x1, out x2));
            Console.ReadKey();
        }
    }
}
