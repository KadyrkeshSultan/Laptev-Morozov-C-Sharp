using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] argc)
        {
            string folderName = @"D:\";
            string fileName = "1.txt";
            string fileName2 = "2.txt";
            string pathstring = System.IO.Path.Combine(folderName, "cs_practice");
            System.IO.Directory.CreateDirectory(pathstring);
            System.IO.File.Create(System.IO.Path.Combine(pathstring, fileName));
            System.IO.File.Create(System.IO.Path.Combine(pathstring, fileName2));
            System.IO.Directory.CreateDirectory(System.IO.Path.Combine(pathstring, "rand1"));
            System.IO.Directory.CreateDirectory(System.IO.Path.Combine(pathstring, "rand2"));
            string FileCopy1 = System.IO.Path.Combine(pathstring, fileName);
            string destFile1 = System.IO.Path.Combine(System.IO.Path.Combine(pathstring,"rand1",fileName));
            string FileCopy2 = System.IO.Path.Combine(pathstring, fileName2);
            
            Console.ReadKey();
        }
    }
}
