﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAppConsole
{
    class Man
    {
        protected string name;
        protected uint age;
        protected double weight;
        protected string sex;
        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetAge(uint age)
        {
            this.age = age;
        }
        public void SetWeight(double weight)
        {
            this.weight = weight;
        }
    }
    class Student : Man
    {
        uint learn_year;
        public void incYear(uint year)
        {
            learn_year += year;
        }
        public void ChangeYear(uint year)
        {
            learn_year = year;
        }
        public Student(string name, uint age, double weight, string sex, uint learn_year)
        {
            SetName(name);
            SetAge(age);
            SetWeight(weight);
            this.sex = sex;
            this.learn_year = learn_year;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Student stu = new Student("Madina", 18, 50, "zh", 2017);
            Console.ReadKey();
        }
    }
}
