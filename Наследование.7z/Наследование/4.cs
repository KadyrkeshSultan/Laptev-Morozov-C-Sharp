﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAppConsole
{
    class Liquid
    {
        protected string name;
        protected double plotnost;
        public void SetName(string Name)
        {
            name = Name;
        }
        public void SetPlotnost(double Plotnost)
        {
            plotnost = Plotnost;
        }
        public Liquid(string Name, double Plotnost)
        {
            name = Name;
            plotnost = Plotnost;
        }
    }
    class Alcohol : Liquid
    {
        double krepkost;
        public Alcohol(string Name, double Plotnost, double Krepkost) : base(Name, Plotnost)
        {
            krepkost = Krepkost;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Alcohol vodka = new Alcohol("Vodka", 900, 40);
            Console.ReadKey();
        }
    }
}
